// lib/pages/favorites/favorites_page.dart

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:cp_flutter/models/movie_model.dart';
import 'package:cp_flutter/pages/movie_detail/movie_detail_page.dart';
import 'dart:convert';
import 'package:cp_flutter/common/utils.dart';

class FavoritesPage extends StatefulWidget {
  const FavoritesPage({super.key});

  @override
  _FavoritesPageState createState() => _FavoritesPageState();
}

class _FavoritesPageState extends State<FavoritesPage> {
  List<Movie> favoriteMovies = [];

  @override
  void initState() {
    super.initState();
    _loadFavorites();
  }

  Future<void> _loadFavorites() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String>? favorites = prefs.getStringList('favorites');

    if (favorites != null) {
      setState(() {
        favoriteMovies = favorites
            .map((movieJson) => Movie.fromJson(json.decode(movieJson)))
            .toList();
      });
    }
  }

  Future<void> _removeFavorite(Movie movie) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> favorites = prefs.getStringList('favorites') ?? [];

    String movieJson = json.encode(movie.toJson());
    favorites.remove(movieJson);
    await prefs.setStringList('favorites', favorites);

    setState(() {
      favoriteMovies.remove(movie);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Meus Favoritos'),
      ),
      body: favoriteMovies.isEmpty
          ? const Center(child: Text('Nenhum favorito adicionado.'))
          : ListView.builder(
              itemCount: favoriteMovies.length,
              itemBuilder: (context, index) {
                final movie = favoriteMovies[index];
                return ListTile(
                  leading: Image.network(
                    '$imageUrl${movie.posterPath}',
                    width: 50,
                    fit: BoxFit.cover,
                  ),
                  title: Text(movie.title),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete, color: Colors.red),
                    onPressed: () => _removeFavorite(movie),
                  ),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            MovieDetailPage(movieId: movie.id),
                      ),
                    );
                  },
                );
              },
            ),
    );
  }
}
