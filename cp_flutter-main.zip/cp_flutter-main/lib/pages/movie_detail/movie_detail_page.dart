// lib/pages/movie_detail/movie_detail_page.dart

import 'package:cached_network_image/cached_network_image.dart';
import 'package:cp_flutter/common/utils.dart';
import 'package:cp_flutter/models/movie_detail_model.dart';
import 'package:cp_flutter/models/movie_model.dart';
import 'package:cp_flutter/services/api_services.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart'; // Importar SharedPreferences
import 'dart:convert'; // Importar json
import 'package:url_launcher/url_launcher.dart'; // Importar url_launcher

class MovieDetailPage extends StatefulWidget {
  final int movieId;
  const MovieDetailPage({super.key, required this.movieId});

  @override
  State<MovieDetailPage> createState() => _MovieDetailPageState();
}

class _MovieDetailPageState extends State<MovieDetailPage> {
  ApiServices apiServices = ApiServices();

  late Future<MovieDetailModel> movieDetail;
  late Future<Result> movieRecommendationModel;

  bool isFavorite = false;
  late Movie movie;
  String? trailerUrl;

  @override
  void initState() {
    super.initState();
    fetchInitialData();
  }

  void fetchInitialData() {
    movieDetail = apiServices.getMovieDetail(widget.movieId);
    movieRecommendationModel = apiServices.getMovieRecommendations(widget.movieId);
    apiServices.getMovieTrailer(widget.movieId).then((url) {
      setState(() {
        trailerUrl = url;
      });
    });
  }

  Future<void> toggleFavorite() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> favorites = prefs.getStringList('favorites') ?? [];

    String movieJson = json.encode(movie.toJson());

    if (isFavorite) {
      favorites.remove(movieJson);
    } else {
      favorites.add(movieJson);
    }

    await prefs.setStringList('favorites', favorites);

    setState(() {
      isFavorite = !isFavorite;
    });
  }

  Future<void> checkIfFavorite() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> favorites = prefs.getStringList('favorites') ?? [];

    String movieJson = json.encode(movie.toJson());

    setState(() {
      isFavorite = favorites.contains(movieJson);
    });
  }

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;

    return Scaffold(
      body: SingleChildScrollView(
        child: FutureBuilder<MovieDetailModel>(
          future: movieDetail,
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              final movieDetailModel = snapshot.data!;
              movie = Movie(
                adult: movieDetailModel.adult,
                backdropPath: movieDetailModel.backdropPath,
                genreIds: movieDetailModel.genres.map((genre) => genre.id).toList(),
                id: movieDetailModel.id,
                originalLanguage: movieDetailModel.originalLanguage,
                originalTitle: movieDetailModel.originalTitle,
                overview: movieDetailModel.overview,
                popularity: movieDetailModel.popularity,
                posterPath: movieDetailModel.posterPath,
                releaseDate: movieDetailModel.releaseDate,
                title: movieDetailModel.title,
                video: movieDetailModel.video,
                voteAverage: movieDetailModel.voteAverage,
                voteCount: movieDetailModel.voteCount,
              );

              checkIfFavorite();

              String genresText = movieDetailModel.genres.map((genre) => genre.name).join(', ');

              return Column(
                children: [
                  Stack(
                    children: [
                      Container(
                        height: size.height * 0.4,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            image: NetworkImage("$imageUrl${movieDetailModel.posterPath}"),
                            fit: BoxFit.cover,
                          ),
                        ),
                        child: SafeArea(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              IconButton(
                                icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
                                onPressed: () {
                                  Navigator.pop(context);
                                },
                              ),
                              IconButton(
                                icon: Icon(
                                  isFavorite ? Icons.favorite : Icons.favorite_border,
                                  color: Colors.red,
                                  size: 30,
                                ),
                                onPressed: () {
                                  toggleFavorite();
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 25, left: 10, right: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          movieDetailModel.title,
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        // Botão "Assistir Trailer"
                        if (trailerUrl != null)
                          Padding(
                            padding: const EdgeInsets.only(top: 10.0),
                            child: ElevatedButton.icon(
                              onPressed: () async {
                                Uri url = Uri.parse(trailerUrl!);
                                if (await canLaunchUrl(url)) {
                                  await launchUrl(url, mode: LaunchMode.externalApplication);
                                } else {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text('Não foi possível abrir o trailer'),
                                    ),
                                  );
                                }
                              },
                              icon: const Icon(Icons.play_arrow),
                              label: const Text('Assistir Trailer'),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.red,
                              ),
                            ),
                          ),
                        const SizedBox(height: 15),
                        Row(
                          children: [
                            Text(
                              movieDetailModel.releaseDate.year.toString(),
                              style: const TextStyle(
                                color: Colors.grey,
                              ),
                            ),
                            const SizedBox(width: 30),
                            Text(
                              genresText,
                              style: const TextStyle(
                                color: Colors.grey,
                                fontSize: 17,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 30),
                        Text(
                          movieDetailModel.overview,
                          style: const TextStyle(color: Colors.white, fontSize: 16),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 30),
                  FutureBuilder<Result>(
                    future: movieRecommendationModel,
                    builder: (context, snapshot) {
                      if (snapshot.hasData) {
                        final recommendations = snapshot.data!;
                        return recommendations.movies.isEmpty
                            ? const SizedBox()
                            : Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Padding(
                                    padding: EdgeInsets.symmetric(vertical: 8.0, horizontal: 12.0),
                                    child: Text(
                                      "Mais como este",
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 20),
                                  GridView.builder(
                                    physics: const NeverScrollableScrollPhysics(),
                                    shrinkWrap: true,
                                    padding: EdgeInsets.zero,
                                    itemCount: recommendations.movies.length,
                                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                                      crossAxisCount: 3,
                                      mainAxisSpacing: 15,
                                      childAspectRatio: 1.5 / 2,
                                    ),
                                    itemBuilder: (context, index) {
                                      return InkWell(
                                        onTap: () {
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                              builder: (context) => MovieDetailPage(
                                                  movieId: recommendations.movies[index].id),
                                            ),
                                          );
                                        },
                                        child: CachedNetworkImage(
                                          imageUrl:
                                              "$imageUrl${recommendations.movies[index].posterPath}",
                                        ),
                                      );
                                    },
                                  ),
                                ],
                              );
                      }
                      return const Text("Algo deu errado");
                    },
                  ),
                ],
              );
            }
            return const SizedBox();
          },
        ),
      ),
    );
  }
}
